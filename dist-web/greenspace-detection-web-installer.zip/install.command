#!/bin/bash

cd "$(dirname "$0")"

echo "🌱 Installing Greenspace Detection App (v2.0 - Timeout Fix)..."
echo "============================================================"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Robust Node.js detection
detect_nodejs() {
    print_status "Detecting Node.js installation..."
    
    NODE_PATHS=(
        "/usr/local/bin/node"
        "/opt/homebrew/bin/node"
        "$HOME/.nvm/versions/node/*/bin/node"
        "$(which node 2>/dev/null)"
    )
    
    NPM_PATHS=(
        "/usr/local/bin/npm"
        "/opt/homebrew/bin/npm"
        "$HOME/.nvm/versions/node/*/bin/npm"
        "$(which npm 2>/dev/null)"
    )
    
    # Find working Node.js
    for node_path in "${NODE_PATHS[@]}"; do
        if [[ -n "$node_path" ]] && [[ -x "$node_path" ]]; then
            NODE_CMD="$node_path"
            break
        fi
    done
    
    # Find working npm
    for npm_path in "${NPM_PATHS[@]}"; do
        if [[ -n "$npm_path" ]] && [[ -x "$npm_path" ]]; then
            NPM_CMD="$npm_path"
            break
        fi
    done
    
    if [[ -n "$NODE_CMD" ]] && $NODE_CMD --version >/dev/null 2>&1; then
        NODE_VERSION=$($NODE_CMD --version)
        print_success "Found Node.js: $NODE_VERSION at $NODE_CMD"
    else
        print_error "Node.js is not installed or not working properly."
        echo "   Visit: https://nodejs.org/"
        exit 1
    fi
    
    if [[ -n "$NPM_CMD" ]] && $NPM_CMD --version >/dev/null 2>&1; then
        NPM_VERSION=$($NPM_CMD --version)
        print_success "Found npm: $NPM_VERSION at $NPM_CMD"
    else
        print_error "npm is not installed or not working properly."
        exit 1
    fi
}

print_status "Checking prerequisites..."
detect_nodejs

if ! command -v python3 &> /dev/null; then
    print_error "Python 3 is not installed. Please install Python 3.8+ first."
    exit 1
fi

# Check for Xcode Command Line Tools
print_status "Checking for Xcode Command Line Tools..."
if ! xcode-select -p &> /dev/null; then
    print_warning "Xcode Command Line Tools not found!"
    echo "📋 Please install: xcode-select --install"
    echo "🔄 Continue anyway? (y/N)"
    read -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    print_success "Xcode Command Line Tools found"
fi

INSTALL_DIR="$HOME/Applications/Greenspace Detection"
print_status "Installing to: $INSTALL_DIR"

mkdir -p "$INSTALL_DIR"
cp -r app/* "$INSTALL_DIR/"
cd "$INSTALL_DIR"

print_status "Installing Node.js dependencies..."
if ! "$NPM_CMD" install --no-audit --no-fund; then
    print_warning "Trying without optional dependencies..."
    if ! "$NPM_CMD" install --no-audit --no-fund --no-optional; then
        print_error "Installation failed!"
        exit 1
    fi
fi

print_status "Setting up Python environment with enhanced timeout handling..."
python3 -m venv venv
source venv/bin/activate
pip install -r python_scripts/requirements.txt

# Verify scipy and key dependencies
if python3 -c "import scipy, rasterio, numpy" 2>/dev/null; then
    print_success "Python environment with all dependencies ready"
else
    print_warning "Some Python dependencies may have issues - continuing anyway"
fi

# Create launcher with better error handling
cat > launch.sh << 'LAUNCH_EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "🚀 Starting Greenspace Detection App (Enhanced Timeout Version)..."

NODE_PATHS=(
    "/usr/local/bin/node"
    "/opt/homebrew/bin/node"
    "$HOME/.nvm/versions/node/*/bin/node"
    "$(which node 2>/dev/null)"
)

NPM_PATHS=(
    "/usr/local/bin/npm"
    "/opt/homebrew/bin/npm"
    "$HOME/.nvm/versions/node/*/bin/npm"
    "$(which npm 2>/dev/null)"
)

for node_path in "${NODE_PATHS[@]}"; do
    if [[ -n "$node_path" ]] && [[ -x "$node_path" ]]; then
        NODE_CMD="$node_path"
        break
    fi
done

for npm_path in "${NPM_PATHS[@]}"; do
    if [[ -n "$npm_path" ]] && [[ -x "$npm_path" ]]; then
        NPM_CMD="$npm_path"
        break
    fi
done

if lsof -i :3000 >/dev/null 2>&1; then
    echo "✅ App is already running!"
    open http://localhost:3000 2>/dev/null
    exit 0
fi

pkill -f "next dev" 2>/dev/null || true
pkill -f "npm run dev" 2>/dev/null || true
sleep 2

source venv/bin/activate

echo "⏳ Starting Next.js server with enhanced satellite processing..."
"$NPM_CMD" run dev &
SERVER_PID=$!

for i in {1..30}; do
    if lsof -i :3000 >/dev/null 2>&1; then
        echo "✅ App started successfully!"
        echo "🛰️  Enhanced timeout handling for satellite processing active"
        sleep 1
        open http://localhost:3000 2>/dev/null
        break
    fi
    sleep 1
done

if ! lsof -i :3000 >/dev/null 2>&1; then
    echo "❌ Failed to start server on port 3000"
    exit 1
fi

wait $SERVER_PID
LAUNCH_EOF

chmod +x launch.sh

# Create desktop shortcut
DESKTOP_FILE="$HOME/Desktop/Greenspace Detection.command"
cat > "$DESKTOP_FILE" << 'DESKTOP_EOF'
#!/bin/bash
cd "$HOME/Applications/Greenspace Detection"
pkill -f "next dev" 2>/dev/null || true
pkill -f "npm run dev" 2>/dev/null || true
sleep 1
./launch.sh
DESKTOP_EOF

chmod +x "$DESKTOP_FILE"

print_success "Desktop shortcut created"
print_success "Installation completed successfully!"

echo ""
echo "🚀 To launch: Double-click 'Greenspace Detection.command' on Desktop"
echo "📝 URL: http://localhost:3000"
echo "🛰️  This version includes enhanced timeout handling to prevent 3% hanging"
echo ""
echo "Press any key to close..."
read -n 1
