#!/bin/bash

echo "🌱 Installing Greenspace Detection App..."
echo "========================================"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required but not installed."
    echo "Please install Node.js from: https://nodejs.org/"
    echo "Then run this installer again."
    exit 1
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is required but not installed."
    echo "Please install Python 3 from: https://python.org/"
    echo "Then run this installer again."
    exit 1
fi

# Create installation directory
INSTALL_DIR="$HOME/Applications/Greenspace Detection"
echo "📁 Installing to: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"

# Copy app files
echo "📦 Copying application files..."
cp -r app/* "$INSTALL_DIR/"

# Install Node.js dependencies
echo "📦 Installing Node.js dependencies..."
cd "$INSTALL_DIR"
npm install --production

# Create Python virtual environment
echo "🐍 Setting up Python environment..."
python3 -m venv venv
source venv/bin/activate
pip install -r python_scripts/requirements.txt

# Create launch script
cat > "$INSTALL_DIR/launch.sh" << 'LAUNCH_EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "🚀 Starting Greenspace Detection App..."
npm run start &
sleep 3
open "http://localhost:3000"
LAUNCH_EOF

chmod +x "$INSTALL_DIR/launch.sh"

# Create desktop shortcut (macOS)
if [[ "$OSTYPE" == "darwin"* ]]; then
    cat > "$HOME/Desktop/Greenspace Detection.command" << 'DESKTOP_EOF'
#!/bin/bash
cd "$HOME/Applications/Greenspace Detection"
./launch.sh
DESKTOP_EOF
    chmod +x "$HOME/Desktop/Greenspace Detection.command"
    echo "✅ Desktop shortcut created"
fi

echo ""
echo "✅ Installation completed successfully!"
echo ""
echo "🚀 To launch the app:"
echo "   Double-click 'Greenspace Detection.command' on your Desktop"
echo "   Or run: $INSTALL_DIR/launch.sh"
echo ""
echo "📝 The app will open in your default web browser"
echo "   URL: http://localhost:3000"
echo ""
