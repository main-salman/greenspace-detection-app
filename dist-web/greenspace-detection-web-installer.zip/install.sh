#!/bin/bash

# Make sure we're in the right directory
cd "$(dirname "$0")"

echo "🌱 Installing Greenspace Detection App..."
echo "========================================"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Function to detect Node.js installation
detect_nodejs() {
    print_status "Detecting Node.js installation..."
    
    # Check common Node.js locations
    NODE_PATHS=(
        "/usr/local/bin/node"
        "/opt/homebrew/bin/node"
        "$HOME/.nvm/versions/node/*/bin/node"
        "$(which node 2>/dev/null)"
    )
    
    NPM_PATHS=(
        "/usr/local/bin/npm"
        "/opt/homebrew/bin/npm"
        "$HOME/.nvm/versions/node/*/bin/npm"
        "$(which npm 2>/dev/null)"
    )
    
    # Find working Node.js
    for node_path in "${NODE_PATHS[@]}"; do
        if [[ -n "$node_path" ]] && [[ -x "$node_path" ]]; then
            NODE_CMD="$node_path"
            break
        fi
    done
    
    # Find working npm
    for npm_path in "${NPM_PATHS[@]}"; do
        if [[ -n "$npm_path" ]] && [[ -x "$npm_path" ]]; then
            NPM_CMD="$npm_path"
            break
        fi
    done
    
    # Test Node.js
    if [[ -n "$NODE_CMD" ]] && $NODE_CMD --version >/dev/null 2>&1; then
        NODE_VERSION=$($NODE_CMD --version)
        print_success "Found Node.js: $NODE_VERSION at $NODE_CMD"
    else
        print_error "Node.js is not installed or not working properly."
        echo ""
        echo "📋 Please install Node.js first:"
        echo "   1. Visit: https://nodejs.org/"
        echo "   2. Download and install Node.js 18 or later"
        echo "   3. Restart Terminal and try again"
        echo ""
        exit 1
    fi
    
    # Test npm
    if [[ -n "$NPM_CMD" ]] && $NPM_CMD --version >/dev/null 2>&1; then
        NPM_VERSION=$($NPM_CMD --version)
        print_success "Found npm: $NPM_VERSION at $NPM_CMD"
    else
        print_error "npm is not installed or not working properly."
        echo "   Please reinstall Node.js from https://nodejs.org/"
        exit 1
    fi
}

# Check prerequisites
print_status "Checking prerequisites..."

# Detect Node.js with robust checking
detect_nodejs

if ! command -v python3 &> /dev/null; then
    print_error "Python 3 is not installed. Please install Python 3.8+ first."
    echo "   Visit: https://python.org/"
    exit 1
fi

# Check for Xcode Command Line Tools (required for native module compilation)
print_status "Checking for Xcode Command Line Tools..."
if ! xcode-select -p &> /dev/null; then
    print_warning "Xcode Command Line Tools not found!"
    echo ""
    echo "📋 Some packages require compilation. Please install Xcode Command Line Tools:"
    echo "   Run: xcode-select --install"
    echo "   Follow the prompts to install"
    echo ""
    echo "🔄 Would you like to continue anyway? (y/N)"
    read -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "   Please install Xcode Command Line Tools and try again"
        exit 1
    fi
    print_warning "Continuing without Xcode Command Line Tools (some features may not work)"
else
    print_success "Xcode Command Line Tools found"
fi

# Set installation directory
INSTALL_DIR="$HOME/Applications/Greenspace Detection"

print_status "Installing to: $INSTALL_DIR"

# Create installation directory
mkdir -p "$INSTALL_DIR"

# Copy application files
print_status "Copying application files..."
cp -r app/* "$INSTALL_DIR/"

# Navigate to installation directory
cd "$INSTALL_DIR"

# Install Node.js dependencies with full path
print_status "Installing Node.js dependencies..."

# Try to install with better error handling
if ! "$NPM_CMD" install --no-audit --no-fund; then
    print_error "npm install failed!"
    echo ""
    echo "🔧 This is usually due to:"
    echo "   1. Missing Xcode Command Line Tools (run: xcode-select --install)"
    echo "   2. Network connectivity issues"
    echo "   3. Native module compilation problems"
    echo ""
    echo "🔄 Trying alternative installation without optional dependencies..."
    
    if ! "$NPM_CMD" install --no-audit --no-fund --no-optional; then
        print_error "Alternative installation also failed!"
        echo ""
        echo "📋 Manual fix steps:"
        echo "   1. Install Xcode Command Line Tools: xcode-select --install"
        echo "   2. Restart Terminal"
        echo "   3. Try the installation again"
        exit 1
    else
        print_warning "Installed without optional dependencies (some features may be limited)"
    fi
fi

# Verify Next.js installation
if [[ ! -f "node_modules/.bin/next" ]]; then
    print_error "Next.js installation failed!"
    echo "   Please check your internet connection and try again"
    exit 1
fi

print_success "Node.js dependencies installed successfully"

# Create Python virtual environment
print_status "Setting up Python environment with scipy..."
python3 -m venv venv
source venv/bin/activate
pip install -r python_scripts/requirements.txt

# Verify scipy installation
if python3 -c "import scipy" 2>/dev/null; then
    print_success "Python environment with scipy set up successfully"
else
    print_error "Failed to install scipy. Some processing features may not work."
fi

# Create launch script with robust Node.js handling
cat > launch.sh << 'LAUNCH_EOF'
#!/bin/bash
cd "$(dirname "$0")"
echo "🚀 Starting Greenspace Detection App..."

# Find Node.js and npm (same logic as installer)
NODE_PATHS=(
    "/usr/local/bin/node"
    "/opt/homebrew/bin/node"
    "$HOME/.nvm/versions/node/*/bin/node"
    "$(which node 2>/dev/null)"
)

NPM_PATHS=(
    "/usr/local/bin/npm"
    "/opt/homebrew/bin/npm"  
    "$HOME/.nvm/versions/node/*/bin/npm"
    "$(which npm 2>/dev/null)"
)

# Find working Node.js
for node_path in "${NODE_PATHS[@]}"; do
    if [[ -n "$node_path" ]] && [[ -x "$node_path" ]]; then
        NODE_CMD="$node_path"
        break
    fi
done

# Find working npm
for npm_path in "${NPM_PATHS[@]}"; do
    if [[ -n "$npm_path" ]] && [[ -x "$npm_path" ]]; then
        NPM_CMD="$npm_path"
        break
    fi
done

# Check if app is already running
if lsof -i :3000 >/dev/null 2>&1; then
    echo "✅ App is already running!"
    echo "   Opening browser to: http://localhost:3000"
    open http://localhost:3000 2>/dev/null || echo "   Please open http://localhost:3000 in your browser"
    exit 0
fi

# Kill any existing instances to prevent port conflicts
pkill -f "next dev" 2>/dev/null || true
pkill -f "npm run dev" 2>/dev/null || true
sleep 2

# Activate virtual environment
source venv/bin/activate

# Start the Next.js development server using full path
echo "⏳ Starting Next.js server..."
"$NPM_CMD" run dev &
SERVER_PID=$!

# Wait for server to start
echo "⏳ Waiting for server to start..."
for i in {1..30}; do
    if lsof -i :3000 >/dev/null 2>&1; then
        echo "✅ App started successfully!"
        echo "   Opening browser to: http://localhost:3000"
        sleep 1
        open http://localhost:3000 2>/dev/null || echo "   Please open http://localhost:3000 in your browser"
        break
    fi
    sleep 1
done

# Check if server started successfully
if ! lsof -i :3000 >/dev/null 2>&1; then
    echo "❌ Failed to start server on port 3000"
    echo "   Please check if another application is using port 3000"
    echo "   Or try running: $NPM_CMD run dev"
    exit 1
fi

# Keep the script running
wait $SERVER_PID
LAUNCH_EOF

chmod +x launch.sh

# Create desktop shortcut
DESKTOP_FILE="$HOME/Desktop/Greenspace Detection.command"
cat > "$DESKTOP_FILE" << 'DESKTOP_EOF'
#!/bin/bash
cd "$HOME/Applications/Greenspace Detection"
# Kill any existing instances first to prevent port conflicts
pkill -f "next dev" 2>/dev/null || true
pkill -f "npm run dev" 2>/dev/null || true
sleep 1
# Launch the app
./launch.sh
DESKTOP_EOF

chmod +x "$DESKTOP_FILE"

print_success "Desktop shortcut created"
print_success "Installation completed successfully!"

echo ""
echo "🚀 To launch the app:"
echo "   Double-click 'Greenspace Detection.command' on your Desktop"
echo "   Or run: $INSTALL_DIR/launch.sh"
echo ""
echo "📝 The app will open in your default web browser"
echo "   URL: http://localhost:3000"
echo ""
echo "Press any key to close this window..."
read -n 1
