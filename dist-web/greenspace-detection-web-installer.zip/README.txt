Greenspace Detection App - Web Installer
========================================

REQUIREMENTS:
- Node.js 18+ (https://nodejs.org/)
- Python 3.8+ (https://python.org/)

INSTALLATION:

macOS/Linux:
1. Run: ./install.sh
2. Launch: Double-click "Greenspace Detection.command" on Desktop

Windows:
1. Run: install.bat
2. Launch: Double-click "Greenspace Detection.bat" on Desktop

The app will open in your web browser at http://localhost:3000

FEATURES:
✅ Under 100MB download
✅ Automatic dependency installation
✅ Desktop shortcuts created
✅ Same functionality as full desktop app
✅ GitHub compatible file size

For support, visit: [your-repo-url]
