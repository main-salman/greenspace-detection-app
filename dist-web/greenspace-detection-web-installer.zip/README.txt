# Greenspace Detection App - Robust Installer

## Quick Start (Super Easy!)

### Mac:
1. Extract this ZIP file
2. Double-click "install.command" (no Terminal needed!)
3. Double-click "Greenspace Detection.command" on your Desktop

### Windows:
1. Extract this ZIP file
2. Double-click "install.bat"
3. Double-click "launch.bat" in the installation folder

### Linux:
1. Extract this ZIP file
2. Run: ./install.sh
3. Run the launcher script created during installation

## System Requirements

- Node.js 18+ (https://nodejs.org/)
- Python 3.8+ (https://python.org/)
- Internet connection for satellite data

## Troubleshooting

### "next: command not found" error:
- Make sure Node.js is properly installed
- Restart your terminal/command prompt
- Try: npm install -g next

### Python errors:
- Make sure Python 3.8+ is installed
- On some systems, use "python3" instead of "python"

### Port 3000 in use:
- Close other applications using port 3000
- Or visit http://localhost:3001 if the app starts on a different port

## Support

For issues, please check:
1. Node.js version: node --version (should be 18+)
2. Python version: python3 --version (should be 3.8+)
3. Internet connection for satellite data downloads

The installer automatically detects Node.js installations from:
- Standard locations (/usr/local/bin, /opt/homebrew/bin)
- NVM installations
- Conda environments
