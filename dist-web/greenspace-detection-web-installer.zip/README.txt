# Greenspace Detection App - Enhanced Timeout Version

## Quick Installation

### Mac:
1. Extract ZIP file
2. Double-click "install.command"
3. Double-click Desktop shortcut

### Windows:
1. Extract ZIP file  
2. Double-click "install.bat"
3. Run launch.bat

## What's Fixed in This Version

✅ Enhanced timeout handling for satellite data downloads
✅ Better progress reporting during processing
✅ Improved error messages for network issues
✅ Prevents hanging at 3% during satellite processing

## System Requirements

- Node.js 18+
- Python 3.8+
- Xcode Command Line Tools (Mac)
- Internet connection

## Troubleshooting

If processing still gets stuck:
1. Check internet connection
2. Try a different city or date range
3. Restart the app and try again

The enhanced timeout system will automatically retry failed downloads
and provide better feedback about what's happening.
