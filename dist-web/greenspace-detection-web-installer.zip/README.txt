# Greenspace Detection App - Complete Installer

## Quick Start (Super Easy!)

### Mac:
1. Extract this ZIP file
2. Double-click "install.command" (no Terminal needed!)
3. Double-click "Greenspace Detection.command" on your Desktop

### Windows:
1. Extract this ZIP file
2. Double-click "install.bat"
3. Double-click "launch.bat" in the installation folder

## System Requirements

- Node.js 18+ (https://nodejs.org/)
- Python 3.8+ (https://python.org/)
- Internet connection for satellite data
- Xcode Command Line Tools (Mac only, for native modules)

## New in This Version

✅ Added scipy dependency for satellite image processing
✅ Fixed Python scripts directory structure
✅ Fixed Tailwind CSS configuration for proper UI styling
✅ Enhanced Node.js detection for conda environments
✅ Improved error handling and troubleshooting

## Troubleshooting

### "No module named 'scipy'" error:
- The installer now includes scipy in requirements.txt
- If you still see this error, manually install: pip install scipy

### "next: command not found" error:
- Make sure Node.js is properly installed
- Restart your terminal/command prompt

### Native module compilation errors (sharp, node-gyp):
- Install Xcode Command Line Tools: xcode-select --install
- Restart Terminal after installation
- Try the installer again

### Jumbled UI appearance:
- This version fixes Tailwind CSS configuration issues
- UI should now display properly with correct styling

### Python script errors:
- All Python dependencies including scipy are now included
- Scripts are in correct python_scripts/ directory structure

