@echo off
echo Installing Greenspace Detection App (Enhanced Timeout Version)...

node --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js not installed
    pause
    exit /b 1
)

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not installed
    pause
    exit /b 1
)

set INSTALL_DIR=%USERPROFILE%\Applications\Greenspace Detection
mkdir "%INSTALL_DIR%" 2>nul
xcopy /s /e app\* "%INSTALL_DIR%\" >nul
cd /d "%INSTALL_DIR%"

echo Installing dependencies...
npm install
python -m venv venv
call venv\Scripts\activate
pip install -r python_scripts\requirements.txt

echo Creating launcher...
echo @echo off > launch.bat
echo cd /d "%%~dp0" >> launch.bat
echo call venv\Scripts\activate >> launch.bat
echo start http://localhost:3000 >> launch.bat
echo npm run dev >> launch.bat

echo Installation completed! Enhanced timeout handling active.
pause
