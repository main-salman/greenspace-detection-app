@echo off
setlocal enabledelayedexpansion
color 0A
echo 🌱 Installing Greenspace Detection App...
echo ========================================
echo.

REM Check if Node.js is installed
echo 🔍 Checking Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Node.js is not installed. Please install Node.js 18+ first.
    echo    Visit: https://nodejs.org/
    echo.
    pause
    exit /b 1
) else (
    for /f "tokens=*" %%a in ('node --version') do set NODE_VERSION=%%a
    echo ✅ Node.js found: !NODE_VERSION!
)

REM Check if Python is installed
echo 🔍 Checking Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python 3 is not installed. Please install Python 3.8+ first.
    echo    Visit: https://python.org/
    echo.
    pause
    exit /b 1
) else (
    for /f "tokens=*" %%a in ('python --version') do set PYTHON_VERSION=%%a
    echo ✅ Python found: !PYTHON_VERSION!
)

echo.
echo ======================================

REM Set installation directory  
set "INSTALL_DIR=%USERPROFILE%\Applications\Greenspace Detection"

echo 📁 Installing to: %INSTALL_DIR%
echo.

REM Create installation directory
if not exist "%INSTALL_DIR%" (
    echo 📂 Creating installation directory...
    mkdir "%INSTALL_DIR%"
    if !errorlevel! neq 0 (
        echo ❌ Failed to create installation directory
        pause
        exit /b 1
    )
)

REM Copy application files
echo 📦 Copying application files...
xcopy /E /I /Y /Q app "%INSTALL_DIR%" >nul
if %errorlevel% neq 0 (
    echo ❌ Failed to copy application files
    pause
    exit /b 1
)
echo ✅ Application files copied

REM Navigate to installation directory
cd /d "%INSTALL_DIR%"

REM Install Node.js dependencies
echo 📦 Installing Node.js dependencies (this may take a few minutes)...
call npm install --silent
if %errorlevel% neq 0 (
    echo ❌ Failed to install Node.js dependencies
    pause
    exit /b 1
)
echo ✅ Node.js dependencies installed

REM Create Python virtual environment
echo 🐍 Setting up Python environment...
python -m venv venv
if %errorlevel% neq 0 (
    echo ❌ Failed to create Python virtual environment
    pause  
    exit /b 1
)

call venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo ❌ Failed to activate Python virtual environment
    pause
    exit /b 1
)

pip install -r python_scripts\requirements.txt --quiet
if %errorlevel% neq 0 (
    echo ❌ Failed to install Python dependencies
    pause
    exit /b 1
)
echo ✅ Python environment setup complete

REM Create robust launch script
echo 📝 Creating launch script...
(
echo @echo off
echo setlocal
echo color 0A
echo cd /d "%%~dp0"
echo echo.
echo echo 🚀 Starting Greenspace Detection App...
echo echo ========================================
echo.
echo REM Check if app is already running
echo netstat -an ^| find "LISTENING" ^| find ":3000" ^>nul 2^>^&1
echo if %%errorlevel%% equ 0 ^(
echo     echo ✅ App is already running!
echo     echo    Opening browser to: http://localhost:3000
echo     start http://localhost:3000
echo     timeout /t 3 /nobreak ^>nul
echo     exit /b 0
echo ^)
echo.
echo REM Kill any existing processes
echo taskkill /f /im node.exe ^>nul 2^>^&1
echo timeout /t 2 /nobreak ^>nul
echo.
echo REM Activate Python environment
echo if not exist "venv\Scripts\activate.bat" ^(
echo     echo ❌ Python environment not found. Please reinstall.
echo     pause
echo     exit /b 1
echo ^)
echo call venv\Scripts\activate.bat
echo.
echo REM Start the server
echo echo 🌐 Starting server...
echo start /MIN cmd /c "npm run dev"
echo.
echo REM Wait and check if server started
echo echo ⏳ Waiting for server to start...
echo for /L %%%%i in ^(1,1,30^) do ^(
echo     timeout /t 1 /nobreak ^>nul
echo     netstat -an ^| find "LISTENING" ^| find ":3000" ^>nul 2^>^&1
echo     if %%%%errorlevel%%%% equ 0 ^(
echo         echo ✅ Server started successfully!
echo         echo    Opening browser to: http://localhost:3000
echo         timeout /t 2 /nobreak ^>nul
echo         start http://localhost:3000
echo         echo.
echo         echo 🎉 Greenspace Detection App is now running!
echo         echo    Keep this window open while using the app.
echo         echo    Close this window to stop the server.
echo         echo.
echo         echo Press any key to stop the server...
echo         pause ^>nul
echo         taskkill /f /im node.exe ^>nul 2^>^&1
echo         exit /b 0
echo     ^)
echo ^)
echo.
echo echo ❌ Failed to start server on port 3000
echo echo    Please check if another application is using port 3000
echo echo    or try running the installer again.
echo pause
echo exit /b 1
) > launch.bat

if %errorlevel% neq 0 (
    echo ❌ Failed to create launch script
    pause
    exit /b 1
)
echo ✅ Launch script created

REM Create desktop shortcut with error handling
echo 🖥️  Creating desktop shortcut...
set "DESKTOP_FILE=%USERPROFILE%\Desktop\Greenspace Detection.bat"

(
echo @echo off
echo echo 🌱 Launching Greenspace Detection...
echo cd /d "%INSTALL_DIR%"
echo if not exist "launch.bat" ^(
echo     echo ❌ Installation files missing. Please reinstall.
echo     pause
echo     exit /b 1
echo ^)
echo call launch.bat
) > "%DESKTOP_FILE%"

if %errorlevel% neq 0 (
    echo ⚠️  Failed to create desktop shortcut
    echo    You can manually run: %INSTALL_DIR%\launch.bat
) else (
    echo ✅ Desktop shortcut created: Greenspace Detection.bat
)

echo.
echo 🎉 Installation completed successfully!
echo ========================================
echo.
echo 🚀 To launch the app:
echo    Method 1: Double-click 'Greenspace Detection.bat' on your Desktop
echo    Method 2: Run: %INSTALL_DIR%\launch.bat  
echo    Method 3: Navigate to %INSTALL_DIR% and double-click launch.bat
echo.
echo 📝 The app will open in your default web browser at:
echo    URL: http://localhost:3000
echo.
echo 💡 Troubleshooting:
echo    - If desktop shortcut is missing, use Method 2 or 3 above
echo    - If port 3000 is busy, close other apps using that port
echo    - For support, visit: https://github.com/main-salman/greenspace-detection-app
echo.
echo Press any key to close this installer...
pause >nul
